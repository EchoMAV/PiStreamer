# import RPi.GPIO as GPIO
# import time
# from buzzer_service import BUZZER_PIN, GPIO_LOW, BuzzerService
# GPIO_HIGH = GPIO.LOW
# GPIO_LOW = GPIO.HIGH


# try:
#     GPIO.setmode(GPIO.BCM)
#     GPIO.setup(6, GPIO.OUT)
#     while True:
#         GPIO.output(6, GPIO.HIGH)
#         time.sleep(.1)
#         GPIO.output(6, GPIO.LOW)
#         time.sleep(.02)
# except KeyboardInterrupt:
#     GPIO.cleanup()
#     print("Goodbye!")



# print("Use case 1: sd card mounted, updates install, monark is unpaired and pair success")
# BuzzerService().single_beep_slow_heartbeat()
# time.sleep(8)
# BuzzerService().three_quick_beeps()
# time.sleep(.5)
# BuzzerService().double_beep_slow_heartbeat()
# time.sleep(8)
# BuzzerService().three_quick_beeps()
# time.sleep(.5)
# BuzzerService().double_beep_slow_heartbeat()
# time.sleep(8)
# BuzzerService().three_quick_beeps()


# print("Use case 2: sd card mounted, updates fail, monark is unpaired and pair success")
# BuzzerService().single_beep_slow_heartbeat()
# time.sleep(5)
# BuzzerService().long_beep()
# time.sleep(.5)
# BuzzerService().double_beep_slow_heartbeat() # quick by half second
# time.sleep(8)
# BuzzerService().three_quick_beeps() quick quick long is success 
# make 



# time.sleep(.5)
# BuzzerService().double_beep_slow_heartbeat()
# time.sleep(8)
# BuzzerService().three_quick_beeps()


# print("Use case 3: sd card mounted, updates install, monark is unpaired and pair failed")
# BuzzerService().single_beep_slow_heartbeat()
# time.sleep(8)
# BuzzerService().three_quick_beeps()
# time.sleep(.5)
# BuzzerService().single_beep_slow_heartbeat()
# time.sleep(8)
# BuzzerService().three_quick_beeps()
# time.sleep(.5)
# BuzzerService().double_beep_slow_heartbeat()
# time.sleep(8)
# BuzzerService().long_beep() sustain beep if error


# print("Use case 4: sd card mounted, no updates install microhard is disconnected")
# BuzzerService().quick_beep()
# time.sleep(2)
# BuzzerService().long_beep()
# try:
#     GPIO.setmode(GPIO.BCM)
#     GPIO.setup(6, GPIO.OUT)
#     for _ in range(0,12):
#             GPIO.output(6, GPIO_LOW)
#             time.sleep(.1)
#             GPIO.output(6, GPIO_HIGH)
#             time.sleep(.02)
#     GPIO.output(6, GPIO_LOW)
# except KeyboardInterrupt:
#     GPIO.cleanup()
#     print("Goodbye!")


# # Success for qr code 
# try:
#     GPIO.setmode(GPIO.BCM)
#     GPIO.setup(6, GPIO.OUT)
#     GPIO.output(6, GPIO_HIGH)
#     time.sleep(.08)
#     GPIO.output(6, GPIO_LOW)
#     time.sleep(.08)
#     GPIO.output(6, GPIO_HIGH)
#     time.sleep(.08)
#     GPIO.output(6, GPIO_LOW)
#     time.sleep(.08)
#     GPIO.output(6, GPIO_HIGH)
#     time.sleep(.4)
#     GPIO.output(6, GPIO_LOW)
# except KeyboardInterrupt:
#     GPIO.cleanup()
#     print("Goodbye!")



# # print("SD Card Detected (no updates)")
# # BuzzerService().quick_beep()

# # print("SD Card Updates in progress")
# # BuzzerService().single_beep_slow_heartbeat()

# # print("Updates succeeded")
# # BuzzerService().three_quick_beeps()



# # print("Updates in progress")
# # BuzzerService().single_beep_slow_heartbeat()
# # print("Updates failed")
# # BuzzerService().long_beep()

# # print("Scanning for qr codes")
# # BuzzerService().double_beep_slow_heartbeat()

# # print("QR code identified")
# # BuzzerService().three_quick_beeps()

# # print("Pairing in progress")
# # BuzzerService().double_beep_slow_heartbeat()

# # print("Pairing succeeded")
# # BuzzerService().three_quick_beeps()

# # print("pairing Failed")
# # BuzzerService().long_beep()

# # print("pure boot up microhard not detected")

